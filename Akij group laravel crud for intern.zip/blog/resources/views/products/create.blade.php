@extends('products.layout')
  
@section('content')
   <style>
    .demo{
        margin-top: 80;
    }
</style>

<style>
      .add-producth{
        margin-top: 80px !important;
      }

  </style>

<div class="row add-producth">

    <div class="col-lg-12 margin-tb demo">
        <div class="pull-left">
            <h2>Add New Product</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('products.index') }}"> Back</a>
        </div>
    </div>
</div>
   
@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
   <style>
       .add-productt{
        margin-top: 30px !important;
       }
   </style>
<form action="{{ route('products.store') }}" method="POST">
    @csrf
  
  
     <div class="row add-productt">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                <input type="text" name="name" class="form-control" placeholder="Name">
            </div>

            <div class="form-group">
                <strong>Price</strong>
                <input type="text" name="detail" class="form-control" placeholder="Enter the product price">
            </div>

                <div class="form-group">
                <strong>Expire date</strong>
                <input type="text" name="date" class="form-control" placeholder="Year-Date-month">
            </div>
        </div>
     

    
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
   
</form>
@endsection