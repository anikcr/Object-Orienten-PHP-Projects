@extends('products.layout')
 
@section('content')

<style>
    
.first{
    margin-top: 50px !important;
}
.table{
    margin-top: 30px;
}
#myInput{
    margin-left: 20px;
    margin-top: 20px;
}
</style>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
    <div class="row">
        <div class="col-lg-12 mt-5 first">
            <div class="pull-left">
                <h2 class="mt-5">Rahim Store</h2>
            </div>
         
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('products.create') }}"> Add a new product</a>
            </div>
        </div>
        <div>

            
               <div class="pull-center">
            
                <input id="myInput" type="text" placeholder="Enter price or date">
                <br><br>
            </div>
        </div>

    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>price</th>
              <th>Expiry date</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($products as $product)
        <tbody id="myTable">
        <tr >
            <td>{{ ++$i }}</td>
            <td>{{ $product->name }}</td>
            <td>{{ $product->detail }}</td>
            <td>{{ $product->date }}</td>
            <td>
                <form action="{{ route('products.destroy',$product->id) }}" method="POST">
   
                    <a class="btn btn-info" href="{{ route('products.show',$product->id) }}">Show</a>
    
                    <a class="btn btn-primary" href="{{ route('products.edit',$product->id) }}">Edit</a>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        </tbody>
        @endforeach
    </table>
  
    {!! $products->links() !!}
      
@endsection