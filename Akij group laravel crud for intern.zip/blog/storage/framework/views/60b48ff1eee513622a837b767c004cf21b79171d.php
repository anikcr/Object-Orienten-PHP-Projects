
 
<?php $__env->startSection('content'); ?>

<style>
    
.first{
    margin-top: 50px !important;
}
.table{
    margin-top: 30px;
}
#myInput{
    margin-left: 20px;
    margin-top: 20px;
}
</style>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
    <div class="row">
        <div class="col-lg-12 mt-5 first">
            <div class="pull-left">
                <h2 class="mt-5">Rahim Store</h2>
            </div>
         
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('products.create')); ?>"> Add a new product</a>
            </div>
        </div>
        <div>

            
               <div class="pull-center">
            
                <input id="myInput" type="text" placeholder="Enter price or date">
                <br><br>
            </div>
        </div>

    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>price</th>
              <th>Expiry date</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody id="myTable">
        <tr >
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->detail); ?></td>
            <td><?php echo e($product->date); ?></td>
            <td>
                <form action="<?php echo e(route('products.destroy',$product->id)); ?>" method="POST">
   
                    <a class="btn btn-info" href="<?php echo e(route('products.show',$product->id)); ?>">Show</a>
    
                    <a class="btn btn-primary" href="<?php echo e(route('products.edit',$product->id)); ?>">Edit</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $products->links(); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/products/index.blade.php ENDPATH**/ ?>