-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2020 at 06:32 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bookinginfo`
--

CREATE TABLE `tbl_bookinginfo` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sdate` varchar(255) NOT NULL,
  `edate` varchar(255) NOT NULL,
  `saddress` varchar(255) NOT NULL,
  `daddress` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `pcode` int(37) NOT NULL,
  `phoneno` varchar(30) NOT NULL,
  `Sphoneno` varchar(40) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `name` varchar(22) NOT NULL,
  `email` varchar(22) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'anik', 'anikk74444@gmail.com', 'id', 'we'),
(2, 'midea', 'anik123@gmail.com', 'rt', 'e'),
(7, 'sakib', '16303066@iubat.edu', '23', 'rr'),
(8, 'sakib', '16303066@iubat.edu', '23', 'rr'),
(11, 'sakib', 'anikk74444@gmail.com', 'id', '77'),
(12, 'Anik', 'anik@gmail.com', 'not', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_photo`
--

CREATE TABLE `tbl_photo` (
  `itemId` int(11) NOT NULL,
  `itemName` varchar(50) NOT NULL,
  `body` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_showsinfo`
--

CREATE TABLE `tbl_showsinfo` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `cname` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `place` varchar(100) NOT NULL,
  `shomoy` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_showsinfo`
--

INSERT INTO `tbl_showsinfo` (`id`, `image`, `cname`, `location`, `place`, `shomoy`) VALUES
(6, 'uploads/5985cb9468.jpg', 'neywork fest', '<p>chicago</p>', '12 jul', '20.20'),
(7, 'uploads/6a96560a35.jpeg', 'Newyork night', '<p>newwork</p>', '14 july', '20.10'),
(8, 'uploads/bb677099cd.webp', 'joy for people', '<p>gorgea</p>', '31 july', '20.10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70'),
(2, '', '2345'),
(3, 'nadia', '1234'),
(4, '', ''),
(5, 'nadia', 'e7023ba77a45f7e84c5ee8a28dd63585'),
(6, 'nadia', 'd93591bdf7860e1e4ee2fca799911215');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_bookinginfo`
--
ALTER TABLE `tbl_bookinginfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_photo`
--
ALTER TABLE `tbl_photo`
  ADD PRIMARY KEY (`itemId`);

--
-- Indexes for table `tbl_showsinfo`
--
ALTER TABLE `tbl_showsinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_bookinginfo`
--
ALTER TABLE `tbl_bookinginfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `tbl_photo`
--
ALTER TABLE `tbl_photo`
  MODIFY `itemId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_showsinfo`
--
ALTER TABLE `tbl_showsinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
