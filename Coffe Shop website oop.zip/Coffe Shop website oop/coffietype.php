<?php include'inc/header.php'?>

<section class="menu-area section-gap" id="coffee">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content pb-60 col-lg-10">
							<div class="title text-center">
								<h1 class="mb-10">What kind of Coffee we serve for you</h1>
								<p>Who are in extremely love with eco friendly system.</p>
							</div>
						</div>
					</div>						
					<div class="row">
						<div class="col-lg-4">
							<div class="single-menu">
								<div class="title-div justify-content-between d-flex">
									<h4>Cappuccino</h4>
									<p class="price float-right">
										$5
									</p>
								</div>
								<p>
									A cappuccino is similar to a latte. However the key difference between a latte and cappuccino is that a cappuccino has more foam and chocolate placed on top of the drink. Further a cappuccino is made in a cup rather than a tumbler glass. It is made as follow
								</p>								
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-menu">
								<div class="title-div justify-content-between d-flex">
									<h4>Americano</h4>
									<p class="price float-right">
										$4
									</p>
								</div>
								<p>
									Usage of the Internet is becoming more common due to rapid advance.
								</p>								
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-menu">
								<div class="title-div justify-content-between d-flex">
									<h4>Espresso</h4>
									<p class="price float-right">
										$9
									</p>
								</div>
								<p>
									 Extract a standard espresso shot with half the amount of water.• Alternatively turn off a normal espresso extraction before the espresso starts to blonde
								</p>								
							</div>
						</div>	
						<div class="col-lg-4">
							<div class="single-menu">
								<div class="title-div justify-content-between d-flex">
									<h4>Macchiato</h4>
									<p class="price float-right">
										$9
									</p>
								</div>
								<p>
									Usage of the Internet is becoming more common due to rapid advance.
								</p>								
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-menu">
								<div class="title-div justify-content-between d-flex">
									<h4>Mocha</h4>
									<p class="price float-right">
										$9
									</p>
								</div>
								<p>
									Usage of the Internet is becoming more common due to rapid advance.
								</p>								
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-menu">
								<div class="title-div justify-content-between d-flex">
									<h4>Coffee Latte</h4>
									<p class="price float-right">
										$9
									</p>
								</div>
								<p>
									1 Shot of espresso in a short glass or espresso cup• A dollop of steamed milk and foam placed on top of the espresso
								</p>								
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-menu">
								<div class="title-div justify-content-between d-flex">
									<h4>Piccolo Latte</h4>
									<p class="price float-right">
										$49
									</p>
								</div>
								<p>
									A double espresso (aka “Doppio”) is just that, two espresso shots in one cup. Therefore a double espresso consists o
								</p>								
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-menu">
								<div class="title-div justify-content-between d-flex">
									<h4>Ristretto</h4>
									<p class="price float-right">
										$49
									</p>
								</div>
								<p>
									The espresso (aka “short black”) is the foundation and the most important part to every espresso based drink. So much so that we’ve written a guide on how to make the perfect espresso shot. But for the purposes of this post an espresso consists of
								</p>								
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-menu">
								<div class="title-div justify-content-between d-flex">
									<h4>Affogato</h4>
									<p class="price float-right">
										$7
									</p>
								</div>
								<p>
									A double espresso (aka “Doppio”) is just that, two espresso shots in one cup. Therefore a double espresso consists o
								</p>								
							</div>
						</div>															
					</div>
				</div>	
			</section>