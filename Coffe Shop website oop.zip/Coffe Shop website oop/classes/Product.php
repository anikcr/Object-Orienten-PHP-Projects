
<?php

$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../helpers/Format.php');


?>

<?php
class Product
{
   private $db;
	private $fm;

 	public function __construct()
 	{
      $this->db = new Database();
      $this->fm= new Format();

 	}
 	 public function productInsert($data, $file)
 	 {
 	 

            $itemName = mysqli_real_escape_string($this->db->link, $data['itemName']);
            
            $body     = mysqli_real_escape_string($this->db->link, $data['body']);
         
            


            $permited  = array('jpg', 'jpeg', 'png', 'gif');
    $file_name = $file['image']['name'];
    $file_size = $file['image']['size'];
    $file_temp = $file['image']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
    $uploaded_image = "uploads/".$unique_image;

    if($itemName == "" ||  $body == ""  )
    {
           $msg = "<span class='error'>field must not be  emptyyyyyyyyyyyy</span>";
           			 return $msg;
    }
    else
    {
    	move_uploaded_file($file_temp, $uploaded_image);


    	$query = "INSERT INTO  tbl_photo(itemName,  body, image) VALUES('$itemName','$body','$uploaded_image')";

    	$inserted_row = $this->db->insert($query);
           		if ($inserted_row)
           		{
           			$msg = "<span class='success'>photo inserted successfully</span>";
           			 return $msg;
           		}
           		else
           		{
            $msg = "<span class='error'> photo not inserted successfully</span>";
           			 return $msg;
           		}
    }


 	 }
   public function contactInsert($data)
   {

      $name = mysqli_real_escape_string($this->db->link, $data['name']);
           
       $email = mysqli_real_escape_string($this->db->link, $data['email']);
           $subject = mysqli_real_escape_string($this->db->link, $data['subject']);
           $message = mysqli_real_escape_string($this->db->link, $data['message']);
           
             
            


           

   


      $query = "INSERT INTO  tbl_contact(name,  email, subject, message) VALUES('$name','$email','$subject' ,'$message')";

      $inserted_row = $this->db->insert($query);
              if ($inserted_row)
              {
                $msg = "<span class='success'>photo inserted successfully</span>";
                 return $msg;
              }
              else
              {
            $msg = "<span class='error'> photo not inserted successfully</span>";
                 return $msg;
              }
    }

   
	 public function getAllproduct()
	 {
		 $query = "SELECT * FROM tbl_photo";
		 $result = $this->db->select($query);
		 return $result;
	 }
   public function getFeaturedProduct()
   {

    $query = "SELECT * FROM tbl_product WHERE type='0' ORDER BY productId DESC LIMIT
     4";
    $result= $this->db->select($query);
    return  $result;
   } 
   public function getNewProduct()
   {
    $query = "SELECT * FROM tbl_product WHERE type='1' ORDER BY productId DESC LIMIT
     4";
    $result= $this->db->select($query);
    return  $result;
   }
   public function getSingleProduct($id)
   {
     $query = "SELECT p.*, c.catName, b.brandName FROM tbl_product as 
      p, tbl_catagory as c, tbl_brand as b WHERE p.catId = c.catId AND p.brandId = b.brandId AND  p.productId = '$id'";
     
       $result= $this->db->select($query);
    return  $result;
   }

  
  public function productByCat($id)
  {
     $catId     = mysqli_real_escape_string($this->db->link, $id);
     
   $query = "SELECT * FROM tbl_product photo WHERE ItemId ='$catId'"; 
     
    $result= $this->db->select($query);
    return  $result;
  }
  public function delProByid($id)
  {
    $query = " SELECT * FROM tbl_photo WHERE itemId = '$id'";
    $getdata = $this->db->select($query);

    if($getdata)
    {
      while($delimg = $getdata->fetch_assoc())
      {
          $dellink = $delimg['image'];
          unlink($dellink);
      }
    }
    $delquery = "DELETE FROM tbl_photo WHERE  itemId = '$id'";

$deldata = $this->db->delete($delquery);

    if($deldata)
{

  $msg = "<span class='success'>product deleted successfully</span>";
                 return $msg;
      }
      else
      {
         $msg = "<span class='error'>product not deleted successfully</span>";
                 return $msg;
      }

  }
 }
