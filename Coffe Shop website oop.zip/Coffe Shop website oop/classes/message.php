<?php

$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../helpers/Format.php');


?>
<?php
class message


{
   private $db;
	private $fm;

 	public function __construct()
 	{
      $this->db = new Database();
      $this->fm= new Format();

 	}
 	public function contactInsert($data)
   {

      $name = mysqli_real_escape_string($this->db->link, $data['name']);
           
       $email = mysqli_real_escape_string($this->db->link, $data['email']);
           $subject = mysqli_real_escape_string($this->db->link, $data['subject']);
           $message = mysqli_real_escape_string($this->db->link, $data['message']);
           
              $query = "INSERT INTO  tbl_contact(name,  email, subject, message) VALUES('$name','$email','$subject' ,'$message')";

      $inserted_row = $this->db->insert($query);
              if ($inserted_row)
              {
                $msg = "<span class='success'>photo inserted successfully</span>";
                 return $msg;
              }
              else
              {
            $msg = "<span class='error'> photo not inserted successfully</span>";
                 return $msg;
              }
    }


}
?>