

<?php include 'classes/Product.php';?>
 <?php include_once 'helpers/Format.php';?>

 <head>
  

<meta charset="UTF-8">
	<link href="https://fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
<link rel="stylesheet" href="css/gallery-grid.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<title>lightbox</title>

</head>

<?php
$pd = new Product();
$fm= new Format();

?>
<?php

if(isset($_GET['delpro']))
{
  $id = $_GET['delpro'];

  $delpro = $pd->delProByid($id);
}
?>
<body>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Post List</h2>
        <div class="block">

<div class="p-3 mb-2 bg-secondary text-white">
<div class="container">
<div class="container gallery-container">
 
  
    <p class="page-description text-center"></p>
 <div class="tz-gallery">
 	
          <div class="row mb-3">
    	
	      <div class="section group">
                       <?php
                      if(isset($delpro))
                      {
                        
                        echo  $delpro;

                      }  
                      ?>
            <table class="data display datatable" id="example">
			<thead>
				<tr>
					
					
					<th>Image</th>       
					
				</tr>
			</thead>
			<tbody>
			<?php
			   $getpd = $pd->getAllproduct();
			   if($getpd)
			   {
				   $i= 0;
				   while ($result = $getpd->fetch_assoc())
				   {
					   $i++;
			   
			?>
				  <div class="col-md-4">
							  <div class="card">
					<a class="lightbox" href="admin/<?php echo $result['image']; ?>"><img src="admin/<?php echo $result['image']; ?>" alt="" class="card-img-top" /> </a>
					  
					
				     

				  </div>
				</div>
				<?php 
				
				}
			   }
			   
			   ?>
				
			</tbody>
		</table>

       </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>



<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>

<script  src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
<script>
    baguetteBox.run('.tz-gallery');
</script>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
		setSidebarHeight();
    });
</script>

  </body>     