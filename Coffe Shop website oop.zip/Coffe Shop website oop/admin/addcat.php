﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Category</h2>
               <div class="block copyblock"> 



               <?php
                                    
 if($_SERVER['REQUEST_METHOD'] == 'POST')
 {
 $name = $_POST['name'];

     $name = mysqli_real_escape_string($db->link, $name);


     //validtion
     if(empty($name))
     {

        echo "<span class='error'> Field must not be empty!!</span>";//red color from layout.css
     }
     else
     {
       $query = "insert into tbl_category(name) values('$name')";
       $catinsert = $db->insert($query);//accessing the methode of database class db
       if($catinsert)
       {
         echo "<span class='success'> catagory inserted successfully!!</span>";//red color from layout.css
       }
       else
       {
echo "<span class='error'> catagory not inserted successfully!!</span>";//red color from layout.css

       }

     }

             
          }



               ?>
                 <form action="" method="post">
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" name="name" placeholder="Enter Category Name..." class="medium" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
       <?php include 'inc/footer.php';?>
