﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/Product.php';?>
 <?php include_once '../helpers/Format.php';?>
<?php
$pd = new Product();
$fm= new Format();

?>
<?php

if(isset($_GET['delpro']))
{
  $id = $_GET['delpro'];

  $delpro = $pd->delProByid($id);
}
?>

<div class="grid_10">
    <div class="box round first grid">
        <h2>Post List</h2>
        <div class="block">

                       <?php
                      if(isset($delpro))
                      {
                        
                        echo  $delpro;

                      }  
                      ?>
            <table class="data display datatable" id="example">
			<thead>
				<tr>
					<th>SL</th>
					<th>Photo Name</th>
					
					<th>Descriptionnnnnnn</th>
					
					<th>Image</th>       
					
				</tr>
			</thead>
			<tbody>
			<?php
			   $getpd = $pd->getAllproduct();
			   if($getpd)
			   {
				   $i= 0;
				   while ($result = $getpd->fetch_assoc())
				   {
					   $i++;
			   
			?>
				<tr class="odd gradeX">
					<td><?php echo $i; ?></td>
					<td><?php echo $result['itemName']; ?></td>
					<td><?php echo $result['body']; ?></td>
					
			         <td><?php echo $fm->textShorten($result['body'], 50); ?></td>
					
				     <td><img src="<?php echo $result['image']; ?>" height="40px" width="60px"/></td>
					
					
				
				<td><a href="postlist.php?proid=<?php echo $result['itemId'];?>">click delete</a> ||
								
							 <a onclick="return confirm('are u sure to delete')" href="?delpro=<?php echo 
							 $result['itemId'];?>">Delete</a></td>
				</tr>
				<?php 
				
				}
			   }
			   
			   ?>
				
			</tbody>
		</table>

       </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
		setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>
       