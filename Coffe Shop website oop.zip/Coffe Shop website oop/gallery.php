<?php include 'inc/header.php';?>
 

<head>
  

<meta charset="UTF-8">
	<link href="https://fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
<link rel="stylesheet" href="css/gallery-grid.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<title>lightbox</title>

</head>

  <style>
 body {
 

}
</style>

<?php
if (!isset($_GET['itemId']) || $_GET['itemId'] == NULL)
{
  echo "<script>window.location = '404.php';</script>";
}
else
{
  $id = preg_replace('/[^-a-zA-Z0-9_]/', '',$_GET['itemId']);
}

?>	
<body>
  <style>
    div { background-image: url("banner_bg.png")!important;} 
 
</style> 
<div class="p-3 mb-2 bg-secondary text-white">
<div class="container">
<div class="container gallery-container">
 
  
    <p class="page-description text-center"></p>
 <div class="tz-gallery">
          <div class="row mb-3">
    	
	      <div class="section group">
	      	<?php
                $productbycat = $pd->productByCat($id);
                if($productbycat)
                {
                	while ($result =$productbycat->fetch_assoc())
                	{



	      	?>           
			                
				            <div class="col-md-4">
							  <div class="card">
					<a class="lightbox" href="admin/<?php echo $result['image']; ?>"><img src="admin/<?php echo $result['image']; ?>" alt="" class="card-img-top" /> </a>
					  
					 
					
				     

				  </div>
				</div>
			<?php
                
              	}  }
              
			?>
       </div>
</div>
 </div>
</div>
</div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>



<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>

<script  src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
<script>
    baguetteBox.run('.tz-gallery');
</script>
</body>

