
<?php include 'inc/header.php';?>
 <div class="main">
    <div class="content">
    	
			    	<div class="section group">
						<div class="not found"></div>
						<h2>not found</h2>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>

   <?php include 'inc/footer.php';?>	