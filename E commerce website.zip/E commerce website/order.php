<?php include 'inc/header.php';?>

<?php
  $login =  Session::get("cuslogin");
  if($login== false){

  	header("Location:login.php");
  }
?>

<div class="header_bottom">
		<div class="header_bottom_left">
			<div class="section group">


							
			
			</div>
			<div class="section group">
						
				
			</div>
		  <div class="clear"></div>
		</div>
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
             
			<section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<li><img src="images/a.jpg" alt=""/></li>
						<li><img src="images/aa.jpg" alt=""/></li>
						<li><img src="images/aaa.jpg" alt=""/></li>
						<li><img src="images/aaaa.jpg" alt=""/></li>
				    </ul>
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
  </div>