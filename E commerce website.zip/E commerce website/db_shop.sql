-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2020 at 06:28 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `subject`, `description`) VALUES
(7, 'hafiz', 'anikcr464@gmail.com', '32', '56'),
(8, 'anik', 'anikk74444@gmail.com', '32', 'like'),
(9, 'nadia', 'anikk74444@gmail.com', 'id', 'tt');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminID` int(11) NOT NULL,
  `adminName` varchar(233) NOT NULL,
  `adminUser` varchar(255) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminPass` varchar(255) NOT NULL,
  `level` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminID`, `adminName`, `adminUser`, `adminEmail`, `adminPass`, `level`) VALUES
(1, 'anik cr', 'admin', 'admin@gmail.com', '123', '0'),
(3, 'nadia', 'nadia', 'nadia@', '321', '0'),
(4, 'bosss', 'boss', 'bos@', '789', '7'),
(5, 'bosss', 'boss', 'bos@', '789', '7'),
(6, 'we', 'nik', 'nik@', 'dbc4d84bfcfe2284ba11beffb853a8c4', '9'),
(7, 'anik', 'nika', '@we', '1234', '10'),
(8, 'hafiz', 'hafiz', '@hafiz', 'a961e331badc18b259930a8cf9fe91b7', '11'),
(9, 'skate', 'admin', 'admin@gmail.com', 'b99da6afb822d9160a302091df4a7629', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `brandId` int(11) NOT NULL,
  `brandName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`brandId`, `brandName`) VALUES
(1, 'highest rate'),
(6, 'highest rate'),
(8, 'highest rate'),
(9, 'good');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cartId` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cartId`, `sId`, `productId`, `productName`, `price`, `quantity`, `image`) VALUES
(1, 'baphb2iebqs8si1j884q4lsvn6', 11, 'Natural photo', 34.67, 1, 'uploads/07f92e83aa.jpg'),
(2, 'baphb2iebqs8si1j884q4lsvn6', 11, 'Natural photo', 34.67, 1, 'uploads/07f92e83aa.jpg'),
(3, 'baphb2iebqs8si1j884q4lsvn6', 11, 'Natural photo', 34.67, 1, 'uploads/07f92e83aa.jpg'),
(4, 'baphb2iebqs8si1j884q4lsvn6', 11, 'Natural photo', 34.67, 1, 'uploads/07f92e83aa.jpg'),
(5, 'baphb2iebqs8si1j884q4lsvn6', 10, 'water nature', 600.00, 1, 'uploads/1cbb100963.jpg'),
(6, 'baphb2iebqs8si1j884q4lsvn6', 9, 'ca bat', 890.00, 1, 'uploads/4a44c017ea.jpg'),
(7, 'baphb2iebqs8si1j884q4lsvn6', 10, 'water nature', 600.00, 1, 'uploads/1cbb100963.jpg'),
(8, 'baphb2iebqs8si1j884q4lsvn6', 9, 'ca bat', 890.00, 1, 'uploads/4a44c017ea.jpg'),
(9, 'baphb2iebqs8si1j884q4lsvn6', 11, 'Natural photo', 34.67, 1, 'uploads/07f92e83aa.jpg'),
(10, 'baphb2iebqs8si1j884q4lsvn6', 10, 'water nature', 600.00, 3, 'uploads/1cbb100963.jpg'),
(11, 'baphb2iebqs8si1j884q4lsvn6', 10, 'water nature', 600.00, 1, 'uploads/1cbb100963.jpg'),
(15, 'oone2b78gf6v7f8p4klq8vb1c8', 10, 'water nature', 600.00, 1, 'uploads/1cbb100963.jpg'),
(16, 'oone2b78gf6v7f8p4klq8vb1c8', 9, 'ca bat', 890.00, 1, 'uploads/4a44c017ea.jpg'),
(17, 'oone2b78gf6v7f8p4klq8vb1c8', 10, 'water nature', 600.00, 1, 'uploads/1cbb100963.jpg'),
(18, '26ugrmharlu75ndnl0edda8jc8', 11, 'Natural photo', 34.67, 1, 'uploads/07f92e83aa.jpg'),
(19, 'dvkfugi7evptkqoe4hqnccg6nt', 11, 'Natural photo', 34.67, 1, 'uploads/07f92e83aa.jpg'),
(20, 'dvkfugi7evptkqoe4hqnccg6nt', 9, 'ca bat', 890.00, 1, 'uploads/4a44c017ea.jpg'),
(21, '550tf94uc26cg8blltl8hidkfn', 12, 'animal photo', 600.00, 1, 'uploads/d3bd9773a6.jpg'),
(22, 'olb6ro14u0gp4jhn6ljtsjeat8', 22, 'my first', 456.00, 1, 'uploads/9e0385a5e4.jpg'),
(23, 'of43hhr69nqtti1vu6q8c6d10i', 51, 'Natural photo', 0.00, 1, 'uploads/ae90d8063c.jpg'),
(24, 'vgb2141rtpr95su48k1i7nroc1', 51, 'Natural photo', 0.00, 1, 'uploads/ae90d8063c.jpg'),
(25, '6s38nbomebtefqquu0e951h18p', 51, 'Natural photo', 0.00, 1, 'uploads/ae90d8063c.jpg'),
(26, '6s38nbomebtefqquu0e951h18p', 51, 'Natural photo', 0.00, 1, 'uploads/ae90d8063c.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_catagory`
--

CREATE TABLE `tbl_catagory` (
  `catId` int(11) NOT NULL,
  `catName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_catagory`
--

INSERT INTO `tbl_catagory` (`catId`, `catName`) VALUES
(6, 'WEB DESIGNS'),
(7, 'Logo Design'),
(8, 'USER BAR DESIGN'),
(9, 'BANNER DESIGN'),
(10, 'SIGNATURE DESIGNS'),
(12, 'MISC DESIGN');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `zip` varchar(30) NOT NULL,
  `phone` varchar(37) NOT NULL,
  `email` varchar(60) NOT NULL,
  `pass` int(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `address`, `city`, `country`, `zip`, `phone`, `email`, `pass`) VALUES
(7, 'rony', 'uttara', 'barishal', 'bd', '123', 'o19087648', 'hrronyiubat@gmail.com', 827);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `catId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `body` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`productId`, `productName`, `catId`, `brandId`, `body`, `image`, `type`) VALUES
(47, 'banner 1', 9, 6, '<p>tt</p>', 'uploads/a87fc87d16.jpg', 0),
(50, 'this is my logo', 7, 9, '<p>good</p>', 'uploads/8cf7b5fcbf.jpg', 1),
(51, 'Natural photo', 9, 9, '<p>this is mis</p>', 'uploads/ae90d8063c.jpg', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`brandId`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cartId`);

--
-- Indexes for table `tbl_catagory`
--
ALTER TABLE `tbl_catagory`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`productId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `brandId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `tbl_catagory`
--
ALTER TABLE `tbl_catagory`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
