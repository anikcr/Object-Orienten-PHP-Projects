<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
               <li><a class="menuitem">Site Option</a>
                    <ul class="submenu">
                        <li><a href="titleslogan.php">Title & Slogan</a></li>
                        <li><a href="social.php">Social Media</a></li>
                        <li><a href="copyright.php">Copyright</a></li>
                        
                    </ul>
                </li>
				
                 <li><a class="menuitem">Update  your Pages</a>
                    <ul class="submenu">
                        <li><a>About Us</a></li>
                        <li><a>Contact Us</a></li>
                    </ul>
                </li>
				<li><a class="menuitem">Slider Option</a>
                    <ul class="submenu">
                        <li><a href="slideradd.php">Add Slider</a> </li>
                        <li><a href="sliderlist.php">Slider List</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Photo Category Option</a>
                    <ul class="submenu">
                        <li><a href="catadd.php">Add new Category</a> </li>
                        <li><a href="catlist.php"> See the Category List</a> </li>
                    </ul>
                </li>
                 <li><a class="menuitem">top rating Option</a>
                    <ul class="submenu">
                        <li><a href="brandadd.php">Add ratting name</a> </li>
                        <li><a href="brandlist.php">photo List</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Upload Option</a>
                    <ul class="submenu">
                        <li><a href="productadd.php">Upload new photo </a> </li>
                        <li><a href="productlist.php">See the uploaded photo</a> </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>