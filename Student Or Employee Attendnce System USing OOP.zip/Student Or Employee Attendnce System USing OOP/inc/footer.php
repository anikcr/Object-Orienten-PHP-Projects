<div class="well ">

           <h3>website:ntl ninja</h3>
           <span class="pull-right">like us: www.facebook.com/anikcr</span>

	</div>

</div>

</body>
</html>