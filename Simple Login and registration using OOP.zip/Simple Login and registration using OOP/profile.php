<?php
include'lib/User.php';
include'inc/header.php';
Session::checkSession();
?>
<?php
// catch database id
if (isset($_GET['id']))
{
	$userid = (int)$_GET['id'];
}
//update
$user = new user();
 if($_SERVER['REQUEST_METHOD'] == 'POST'&& isset($_POST['update']))
	  {
		  $updateuser = $user->updateUserData($userid, $_POST);
	  }
?>
<div class="panel panel-defult">
<div class="panel-heading">
<div class="panel-heading">
	            <h2> user profile <span class="pull-right"><a class="btn btn-primary"href="index.php">Back</a></span></h2>
	</div>

</div>
<div class="panel-body">
       <div style="max-width:600px; margin:0 auto">
	   <?php
	   if(isset($updateuser ))
	   {
		   echo $updateuser ;
	   }
	   
	   ?>
	   <?php
	   $userdata = $user->getUserByid($id);
	   if($userdata)
	   {
	   ?>
       <form action="" method="POST">
    <div class="form-group"> 
              <label for="email"> name</label>
              <input type="text" id="name" name="name" class="form-control" value="<?php echo $userdata->name; ?>"/>	
</div>
 <div class="form-group"> 
              <label for="email"> username</label>
              <input type="text" id="username" name="username" class="form-control" value="<?php echo $userdata->username; ?>"/>	
</div>
 <div class="form-group"> 
              <label for="email"> email address</label>
              <input type="text" id="email" name="email" class="form-control" value="<?php echo $userdata->email; ?>"/>	
</div>

 
<?php
// only personal info can update and password change
$sesId = Session::get("id");
if($id == $sesId)
{
?>

        <button type="submit" name="update" class="btn btn-success">update</button>
		
		<a class="btn btn-info" href="changepass.php?id=<?php echo $userid;?><?php  echo $userid;?>">
		password change</a>
	   <?php } ?>
    </div>
</form>
	   <?php } ?>
</div>
      
    </div>
    </div>
 
	
	<?php
	include'inc/footer.php';
	?>

	
