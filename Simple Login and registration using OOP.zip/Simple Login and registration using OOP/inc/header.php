<?php
$filepath = realpath(dirname(__FILE__));
include_once $filepath.'/../lib/Session.php';
session::init();
?>

<!DOCTYPE html>
<html>
<head>
<title> login  </title>
<link rel="stylesheet" href="inc/bootstrap.min.css<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head
<?php
if (isset($_GET['action'])&& $_GET['action'] == "logout")
{
	Session::destroy();
}
?>


<body>
                  <div class="container">
                   <nav class="navbar navbar-default">
                     <div class="container-fluid">
                    <div class="navbar-header">
                  <a class="navbar-brand" href="index.php"> login page</a>
</div>
<ul class="nav navbar-nav pull-right">
<!-- if login there will show profile logout -->
<?php
$id = Session::get("id");
$userlogin = Session::get("login");
if($userlogin == true){
?>
           <li><a href="index.php">Home</a></li>
          <li><a href="profile.php?id=><?php echo $id; ?>">profile</a></li>
          <li><a href="?action=logout">logout</a></li>
<?php }else{?>

            <li><a href="Login.php">login</a></li>
           <li><a href="register.php">register</a></li>
		   
<?php } ?>

        
         
	</ul>
	
  </div>
  
</nav>
