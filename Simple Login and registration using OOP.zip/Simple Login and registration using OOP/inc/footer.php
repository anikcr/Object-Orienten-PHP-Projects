<div class="well">
	          <h4>wwwww.future shop.com</h4>
	          <span class ="pull-right">  like us</span>
	</div>
	</div>
</body>
</html>