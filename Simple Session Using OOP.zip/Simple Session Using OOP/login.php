<?php
session_start();
if($_POST['name']=='abc'&& $_POST['password']=='123')
{
	$_SESSION['username']=$_POST['name'];
	echo"hellow".$_SESSION['username']."you are login";
	echo"<a href='logout.php'> logout </a>";
}
else
	die("password or usernmae not match");
?>
<?php
$str ="<h2>i am learning php.<h2>";
$newstr = filter_var($str, FILTER_SANITIZE_STRING);
echo $newstr;
?>
<?php
$int=60.6;
if(filter_var($int, FILTER_VALIDATE_INT))
{
	echo"$int is int number";
}
else{
	echo"$int is not int number";
}

?>