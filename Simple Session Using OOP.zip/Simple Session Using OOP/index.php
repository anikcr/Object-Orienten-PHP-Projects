<?php
if(!isset($_COOKIE['visited']))
{
setcookie("visited","1", time()+10,"/") or die("could not set cokie");
echo"this is your firsst visit.";
}
else
{
	echo"you are uor old visitor";
}
?>
<!DOCTYPE html>
<html>
<body>



<form action="login.php" method="POST">
Username:<input type="text" name="name">
password:<input type="password" name="password">
<button>submit</button>
 
</form>



</body>
</html>