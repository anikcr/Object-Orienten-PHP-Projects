<?php include'conn.php';?>
<?php
if(isset($_REQUEST['id'])){
	$serial=$_REQUEST['id'];
}


$sql = "DELETE FROM water_info WHERE serial=$serial";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}
header('location: water-view.php');
?>