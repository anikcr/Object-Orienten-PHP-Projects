<?php include'conn.php';?>
<html>
	<head>
		<title>
			This is title
		</title>
		<link href="css/style.css" type="text/css" rel="stylesheet"/>
	</head>
	<body>
		<h3>Irrigation Mamnagement System</h3>
		<?php
		if(isset($_REQUEST['id'])){
				$serial=$_REQUEST['id'];
			}
			if(isset($_POST['form1'])){
				$plant_type=$_POST['plant_type'];
				$previous_date=$_POST['previous_date'];
				$next_date=$_POST['next_date'];
				$sql = "UPDATE pesticide_info SET plant_type='$plant_type', previous_date='$previous_date', next_date='$next_date' WHERE serial=$serial";
				if(empty($plant_type)){
					echo"Input the value of Plant type<br/>";
				}
				if(empty($previous_date)){
					echo"Input the value of date</br>";
				}
				if(empty($next_date)){
					echo"Input the value of Next date</br>";
				}

				else if ($conn->query($sql) === TRUE) {
					echo "record Update successfully";
				} else {
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
			}
		?>
		<form action="" method="post">
			<table>
				<tr>
					<td>Plant Type</td>
					<td><input type="text" placeholder="Plant Type" name="plant_type" value=""/></td>
				</tr>
				<tr>
					<td>previous Date</td>
					<td><input type="text" placeholder=" previous Date" name="previous_date" value=""/></td>
				</tr>
				<tr>
					<td>Next Date</td>
					<td><input type="text" placeholder="Next Date" name="next_date" value=""/></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Submit"name="form1"/></td>
					<td></td>
				</tr>
			</table>
			</form>
		
	</body>
</html>