<?php include'header.php';?>
	<div class="content">
	
<h3>Irrigation Mamnagement System</h3>
		<?php
			if(isset($_POST['form1'])){
				$plant=$_POST['plant'];
				$date=$_POST['date'];
				$n_date=$_POST['n_date'];
				$sql = "INSERT INTO water_info (plant_type, date, next_date)VALUES ('$plant', '$date', '$n_date')";
				if(empty($plant)){
					echo"Input the value of Plant type<br/>";
				}
				if(empty($date)){
					echo"Input the value of date</br>";
				}
				if(empty($n_date)){
					echo"Input the value of Next date</br>";
				}

				else if ($conn->query($sql) === TRUE) {
					echo "New record created successfully";
				} else {
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
			}
		?>
		<form action="" method="post">
			<table>
				<tr>
					<td>Plant Type</td>
					<td><input type="text" placeholder="Plant Type" name="plant" value=""/></td>
				</tr>
				<tr>
					<td>Date</td>
					<td><input type="text" placeholder="Date" name="date" value=""/></td>
				</tr>
				<tr>
					<td>Next Date</td>
					<td><input type="text" placeholder="Next Date" name="n_date" value=""/></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Submit"name="form1"/></td>
					<td></td>
				</tr>
			</table>
			</form>
			</div>
<?php include'footer.php';?>