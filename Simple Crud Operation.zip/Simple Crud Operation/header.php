<?php include'conn.php';?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="description" content="" />
<meta name="keywords" content="" />
<title>Irrigation System</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.dropotron-1.0.js"></script>
<script type="text/javascript" src="js/jquery.slidertron-1.1.js"></script>
<script type="text/javascript">
	$(function() {
		$('#menu > ul').dropotron({
			mode: 'fade',
			globalOffsetY: 11,
			offsetY: -15
		});
	});
</script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="index.php">Irrigation Helping Management  System</a></h1>
		</div>
		
	</div>
	<div id="menu">
		<ul>
		<li><a href="index.php">Home</a></li>
			<li class="first">
				
				<span class="opener">View<b></b></span>
				<ul>
					<li><a href="water-view.php">Water Information</a></li>
					<li><a href="pesticide-view.php">Pesticide Information</a></li>
					<li><a href="plant-view.php">Plant Information</a></li>
				</ul>
			</li>
			<li class="opener">
				
				<span class="opener">Insert<b></b></span>
				<ul>
					<li><a href="water-insert.php">Water Information</a></li>
					<li><a href="pesticide-insert.php">Pesticide Information</a></li>
					<li><a href="plant-insert.php">Plant Information</a></li>
				</ul>
			</li>
			<li class="opener">
				
				<span class="opener">Search<b></b></span>
				<ul>
					<li><a href="water-search.php">Water Information</a></li>
					<li><a href="pesticide-search.php">Pesticide Information</a></li>
					<li><a href="plant-search.php">Plant Information</a></li>
				</ul>
			</li>
		</ul>
		<br class="clearfix" />
	</div>