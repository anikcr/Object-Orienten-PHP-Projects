-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2020 at 06:37 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `irrigation`
--

-- --------------------------------------------------------

--
-- Table structure for table `pesticide_info`
--

CREATE TABLE `pesticide_info` (
  `serial` int(11) NOT NULL,
  `plant_type` varchar(123) NOT NULL,
  `previous_date` varchar(54) NOT NULL,
  `next_date` varchar(88) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesticide_info`
--

INSERT INTO `pesticide_info` (`serial`, `plant_type`, `previous_date`, `next_date`) VALUES
(9, 'paddy', '02-07-2017', '05-09-2017'),
(10, '', '01-01-2017', '05-09-2017'),
(11, 'mango', '01-07-2017', '02-07-2017'),
(12, 'lichi', '01-07-2017', '01-09-2017'),
(13, 'paddy', '01-02-2017', '02-03-2017'),
(14, 'mango', '4444', '333');

-- --------------------------------------------------------

--
-- Table structure for table `plant_info`
--

CREATE TABLE `plant_info` (
  `serial` int(11) NOT NULL,
  `plant_type` varchar(52) NOT NULL,
  `plant_ammount` varchar(100) NOT NULL,
  `plant_location` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plant_info`
--

INSERT INTO `plant_info` (`serial`, `plant_type`, `plant_ammount`, `plant_location`) VALUES
(11, 'lichi', '1200 pice', 'north parth'),
(12, 'paddy', '12 akor', 'lalmatia');

-- --------------------------------------------------------

--
-- Table structure for table `water_info`
--

CREATE TABLE `water_info` (
  `serial` int(11) NOT NULL,
  `plant_type` text NOT NULL,
  `date` varchar(255) NOT NULL,
  `next_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `water_info`
--

INSERT INTO `water_info` (`serial`, `plant_type`, `date`, `next_date`) VALUES
(19, 'paddy', '09-07-2018', '12-09-2018'),
(20, 'mango', '01-07-2017', '09-07-2017'),
(21, 'paddy', '04-07-2017', '09-07-2017'),
(22, 'mango', '09-07-2017', 'o9-07-2017'),
(23, 'lebo', '02-09-2017', '02-09-98'),
(24, 'TEA', '01-02-2017', '23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pesticide_info`
--
ALTER TABLE `pesticide_info`
  ADD PRIMARY KEY (`serial`);

--
-- Indexes for table `plant_info`
--
ALTER TABLE `plant_info`
  ADD PRIMARY KEY (`serial`);

--
-- Indexes for table `water_info`
--
ALTER TABLE `water_info`
  ADD PRIMARY KEY (`serial`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pesticide_info`
--
ALTER TABLE `pesticide_info`
  MODIFY `serial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `plant_info`
--
ALTER TABLE `plant_info`
  MODIFY `serial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `water_info`
--
ALTER TABLE `water_info`
  MODIFY `serial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
