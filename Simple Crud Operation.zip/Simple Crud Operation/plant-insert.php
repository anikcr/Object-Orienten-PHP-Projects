<?php include'header.php';?>
	<div class="content">
	
<h3>Irrigation Mamnagement System</h3>
		<?php
			if(isset($_POST['form1'])){
				$plant_type=$_POST['plant_type'];
				$plant_ammount=$_POST['plant_ammount'];
				$plant_location=$_POST['plant_location'];
				$sql = "INSERT INTO plant_info (plant_type, plant_ammount, plant_location)VALUES ('$plant_type', '$plant_ammount', '$plant_location')";
				if(empty($plant_type)){
					echo"Input the value of Plant type<br/>";
				}
				if(empty($plant_ammount)){
					echo"Input the value of date</br>";
				}
				if(empty($plant_location)){
					echo"Input the value of Next date</br>";
				}

				else if ($conn->query($sql) === TRUE) {
					echo "New record created successfully";
				} else {
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
			}
		?>
		<form action="" method="post">
			<table>
				<tr>
					<td>Plant Type</td>
					<td><input type="text" placeholder="Plant Type" name="plant_type" value=""/></td>
				</tr>
				<tr>
					<td> plant ammount</td>
					<td><input type="text" placeholder="plant ammount" name="plant_ammount" value=""/></td>
				</tr>
				<tr>
					<td>plant location</td>
					<td><input type="text" placeholder="plant location" name="plant_location" value=""/></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Submit"name="form1"/></td>
					<td></td>
				</tr>
			</table>
			</form>
			</div>
<?php include'footer.php';?>