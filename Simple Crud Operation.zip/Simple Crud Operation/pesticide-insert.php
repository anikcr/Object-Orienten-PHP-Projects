<?php include'header.php';?>
	<div class="content">
	
<h3>Irrigation Mamnagement System</h3>
		<?php
			if(isset($_POST['form1'])){
				$plant_type=$_POST['plant_type'];
				$previous_date=$_POST['previous_date'];
				$next_date=$_POST['next_date'];
				$sql = "INSERT INTO pesticide_info (plant_type, previous_date, next_date)VALUES ('$plant_type', '$previous_date', '$next_date')";
				if(empty($plant_type)){
					echo"Input the value of Plant type<br/>";
				}
				if(empty($previous_date)){
					echo"Input the value of date</br>";
				}
				if(empty($next_date)){
					echo"Input the value of Next date</br>";
				}

				else if ($conn->query($sql) === TRUE) {
					echo "New record created successfully";
				} else {
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
			}
		?>
		<form action="" method="post">
			<table>
				<tr>
					<td>Plant Type</td>
					<td><input type="text" placeholder="Plant Type" name="plant_type" value=""/></td>
				</tr>
				<tr>
					<td> previous Date</td>
					<td><input type="text" placeholder="previous Date" name="previous_date" value=""/></td>
				</tr>
				<tr>
					<td>Next Date</td>
					<td><input type="text" placeholder="Next Date" name="next_date" value=""/></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Submit"name="form1"/></td>
					<td></td>
				</tr>
			</table>
			</form>
		
			</div>
<?php include'footer.php';?>