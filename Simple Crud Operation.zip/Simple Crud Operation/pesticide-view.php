<?php include'header.php';?>
<script type="text/javascript">
	$(function() {
	$(function() {
		$('#menu > ul').dropotron({
			mode: 'fade',
			globalOffsetY: 11,
			offsetY: -15
		});
	});
</script>
	<div class="content">
	<center>

		<table cellpadding="5" border="1">
			<tr>
				<th>Plant Type</th>
				<th> previous Date</th>
				<th>Next date</th>
				<th>Action</th>
			</tr>
<?php
					$sql = "SELECT * FROM pesticide_info";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							?>
			<tr>
				<td><?php echo $row['plant_type'];?></td>
				<td><?php echo $row['previous_date'];?></td>
				<td><?php echo $row['next_date'];?></td>
				<td><a href="update pesticide.php?id=<?php echo $row['serial'];?>">Edit</a> | <a href="delete pesticide.php?id=<?php echo $row['serial'];?>">Delete</a> | <button onclick="myFunction()">Print</button></td>
				
			</tr>
							
			<?php	}
			} else {
				echo "0 results";
}?>
		</table>
		</center>
	
	</div>
	

<?php include'footer.php';?>