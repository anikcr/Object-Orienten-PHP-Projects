<?php include'header.php';?>
	<div class="content">
	
		<center>
		<table>
		<form method="post" action="">
			<tr>
				<td><input name="form2"type="submit" value="Search"/></td>
				<td><input type="text" value=""name="search"/>
			</tr>
			
		</table>
		<?php
		if(isset($_POST['form2'])){
			$search=$_POST['search'];
		
		
			?>
		

		<table cellpadding="5" border="1">
			<tr>
				<th>Plant_Type</th>
				<th>previous_Date</th>
				<th>Next_date</th>
			</tr>
		<?php
							$sql = "SELECT * FROM pesticide_info WHERE 	plant_type='$search'";
							$result = $conn->query($sql);

							if ($result->num_rows > 0) {
								while($row = $result->fetch_assoc()) {
									?>
					<tr>
						<td><?php echo $row['plant_type'];?></td>
						<td><?php echo $row['previous_date'];?></td>
						<td><?php echo $row['next_date'];?></td>
						
						
					</tr>
									
					<?php	}
					} else {
						echo "0 results";
		}
		}
		?>
</form>
		</table>
		</center>
		</div>
<?php include'footer.php';?>