<?php include'header.php';?>
	<div class="content">
	
		<center>
		<table>
		<form method="post" action="">
			<tr>
				<td><input name="form2" type="submit" value="Search"/></td>
				<td><input type="text" name="search"/>
			</tr>
			</form>
			
		</table>
		<?php
		if(isset($_POST['form2'])){
			$search=$_POST['search'];
		
		
			?>
		

		<table cellpadding="5" border="1">
			<tr>
				<th>Plant Type</th>
				<th>Date</th>
				<th>Next date</th>
			</tr>
		<?php
							$sql = "SELECT * FROM water_info WHERE 	plant_type='$search'";
							$result = $conn->query($sql);

							if ($result->num_rows > 0) {
								while($row = $result->fetch_assoc()) {
									?>
					<tr>
						<td><?php echo $row['plant_type'];?></td>
						<td><?php echo $row['date'];?></td>
						<td><?php echo $row['next_date'];?></td>
						
						
					</tr>
									
					<?php	}
					} else {
						echo "0 results";
		}
		}
		?>

		</table>
		</center>
		</div>
<?php include'footer.php';?>