<?php
$server='localhost';
$username='root';
$pasword='';
$db='irrigation';

$conn=new mysqli($server,$username,$pasword,$db);
if($conn->connect_error)
{
	die("Connect Failed".$conn->connect_error);
}
?>