<?php include'conn.php';?>
<html>
	<head>
		<title>
			This is title
		</title>
		<link href="css/style.css" type="text/css" rel="stylesheet"/>
	</head>
	<body>
		<h3>Irrigation Mamnagement System</h3>
		<?php
		if(isset($_REQUEST['id'])){
				$serial=$_REQUEST['id'];
			}
			if(isset($_POST['form1'])){
				$plant=$_POST['plant'];
				$date=$_POST['date'];
				$n_date=$_POST['n_date'];
				$sql = "UPDATE water_info SET plant_type='$plant', date='$date', next_date='$n_date' WHERE serial=$serial";
				if(empty($plant)){
					echo"Input the value of Plant type<br/>";
				}
				if(empty($date)){
					echo"Input the value of date</br>";
				}
				if(empty($n_date)){
					echo"Input the value of Next date</br>";
				}

				else if ($conn->query($sql) === TRUE) {
					echo "record Update successfully";
				} else {
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
			}
		?>
		<form action="" method="post">
			<table>
				<tr>
					<td>Plant Type</td>
					<td><input type="text" placeholder="Plant Type" name="plant" value=""/></td>
				</tr>
				<tr>
					<td>Date</td>
					<td><input type="text" placeholder="Date" name="date" value=""/></td>
				</tr>
				<tr>
					<td>Next Date</td>
					<td><input type="text" placeholder="Next Date" name="n_date" value=""/></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Submit"name="form1"/></td>
					<td></td>
				</tr>
			</table>
			</form>
		
	</body>
</html>