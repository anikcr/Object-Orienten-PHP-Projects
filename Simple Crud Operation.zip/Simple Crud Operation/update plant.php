<?php include'conn.php';?>
<html>
	<head>
		<title>
			This is title
		</title>
		<link href="css/style.css" type="text/css" rel="stylesheet"/>
	</head>
	<body>
		<h3>Irrigation Mamnagement System</h3>
		<?php
		if(isset($_REQUEST['id'])){
				$serial=$_REQUEST['id'];
			}
			if(isset($_POST['form1'])){
				$plant_type=$_POST['plant_type'];
				$plant_ammount=$_POST['plant_ammount'];
				$plant_location=$_POST['plant_location'];
				$sql = "UPDATE plant_info SET plant_type='$plant_type', plant_ammount='$plant_ammount', plant_location='$plant_location' WHERE serial=$serial";
				if(empty($plant_type)){
					echo"Input the value of Plant type<br/>";
				}
				if(empty($plant_ammount)){
					echo"Input the value of date</br>";
				}
				if(empty($plant_location)){
					echo"Input the value of plant location</br>";
				}

				else if ($conn->query($sql) === TRUE) {
					echo "record Update successfully";
				} else {
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
			}
		?>
		<form action="" method="post">
			<table>
				<tr>
					<td>Plant Type</td>
					<td><input type="text" placeholder="Plant Type" name="plant_type" value=""/></td>
				</tr>
				<tr>
					<td>plant ammount</td>
					<td><input type="text" placeholder="plant ammount" name="plant_ammount" value=""/></td>
				</tr>
				<tr>
					<td><plant location/td>
					<td><input type="text" placeholder="plant location" name="plant_location" value=""/></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Submit"name="form1"/></td>
					<td></td>
				</tr>
			</table>
			</form>
		
	</body>
</html>