<?php include'header.php';?>
<script type="text/javascript">
	$(function() {
	$(function() {
		$('#menu > ul').dropotron({
			mode: 'fade',
			globalOffsetY: 11,
			offsetY: -15
		});
	});
</script>
	<div class="content">
			<center>

		<table cellpadding="5" border="1">
			<tr>
				<th>Plant Type</th>
				<th> plant ammount</th>
				<th>plant location</th>
				<th>Action</th>
			</tr>
<?php
					$sql = "SELECT * FROM plant_info";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							?>
			<tr>
				<td><?php echo $row['plant_type'];?></td>
				<td><?php echo $row['plant_ammount'];?></td>
				<td><?php echo $row['plant_location'];?></td>
				<td><a href="update plant.php?id=<?php echo $row['serial'];?>">Edit</a> | <a href="delete plant.php?id=<?php echo $row['serial'];?>">Delete</a> | <button onclick="myFunction()">Print</button></td>
				
			</tr>
							
			<?php	}
			} else {
				echo "0 results";
}?>
		</table>
		</center>
	
	</div>
	

<?php include'footer.php';?>